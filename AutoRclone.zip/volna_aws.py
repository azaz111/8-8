import os , time , threading
from argparse import ArgumentParser

def bot(mas , komu):
   #komu=[183787479,292529642]
   os.system('pip install aiogram')
   from aiogram.utils import executor
   from aiogram import Bot, Dispatcher
   bot = Bot(token='5256993370:AAFDtPpjGOvz1ZvsA-On2Bhzh3HGb53R7Gs')
   dp = Dispatcher(bot)
   async def somefunc(masge):
      for komu_m in komu:
         await bot.send_message(komu_m, masge)
   executor.start(dp, somefunc(mas))

def volna(dirs,scolco,json,shag):
   limit=json+shag
   while True:
      if len(os.listdir(dirs)) > int(scolco) :
         unique=[]
         os.system(f'pkill screen')
         dirfiles = os.listdir(dirs)
         for qqq in dirfiles:
            if qqq not in unique and os.stat(dirs+'/'+qqq).st_size > 10865097900:
               unique.append(qqq)
               time.sleep(5)
               print('Zapusk trans  ' + qqq + 'Na Jsone :' + str(json))
               os.system(f'screen -dmS trans{json} rclone move {dirs}/{qqq} aws32: --drive-stop-on-upload-limit --transfers 1 -P --drive-service-account-file "/root/AutoRclone/accounts/{json}.json" -v --log-file /root/rclone1.log;')
               json+=1
               if json == limit: 
                  json=json-shag
         bot('CЛИВАЮЮЮ AWS',[183787479,292529642])
         print('Zapustil vse otdihau')
         time.sleep(7000)
         os.system(f'screen -dmS transfer python3 transfer.py -s {shag} -j {json}')
         os.system('screen -dmS plotter python3 chia_bb_4_pap_ubuntu.py')
         os.system('screen -dmS zapis python3 zapis_baz.py niderlandi_db.py')
      else:
         print('Zhdu obem')

      time.sleep(60) 

if __name__ == '__main__':
   parse = ArgumentParser(description=' Включаем плоттер в зависимрсти от заданного количества .')
   parse.add_argument('--dirs', default='/disk1', help='Путь в который плотить .')
   parse.add_argument('--json', default=False , type=int , help='Стартовый джисон .', required=True)
   parse.add_argument('--shag', default=False , type=int , help='Шаг джисона .', required=True)
   parse.add_argument('--scolco', default=False , type=int, help=' На каком обьеме начать .',  required=True)

   args = parse.parse_args()
   volna(
      scolco=args.scolco,
      dirs=args.dirs,
      json=args.json,
      shag=args.shag
   )